# individual-2c2024

Repositorio de actividades individuales de la materia Arquitectura y Organización del Computador (ex orga2).
Segundo cuatrimestre 2024
