Necesitamos tener un compilador de C y otros *goodies*. Por suerte, ya viene todo pensado listo para ser instalado con el comando:

```shell
$ sudo apt install build-essential
```

Listo!


